import './App.css';
// import Contact from './Components/Contact';
// import Todo from './Components/Todo';
import Aboutus from './Components/Aboutus';
// import  './Components/Contact.css';
// import Contact2 from './Components/Contact2'
function App() {
  return (
    // <h1>Hello</h1>
    <>
    {/* <Todo/> */}
    {/* <Contact/> */}
    
    <Aboutus/>
    </>
  );
}

export default App;
