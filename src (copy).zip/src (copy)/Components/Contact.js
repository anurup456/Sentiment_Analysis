import React from 'react'


const Contact =()=> {
  return (
    <div className='content_body'>
    <div className="contact_info" >
        <div className="container-fluid">
            <div className="row-lg-10 mx-5 justify-content-between">
                <div className="col" style={{display:"flex",justifyContent:'space-between'}}>
                    {/*phone number*/}
                    {/* <div className="contact_info_item">  d-flex justify-content-start align-items-center */}
                    <div className="contact_info_item">
            
                        <img src="https://img.icons8.com/office/24/000000/iphone.png" alt="phone"/>
                        <div className="contact_info_content">
                            <div className="contact_info_title">
                                Phone
                            </div>
                            <div className="contact_info_text">
                                +1234567890

                            </div>

                        </div>

                    </div>
                    {/* {email} */}
                    <div className="contact_info_item">
                        <img src="https://img.icons8.com/fluency/24/000000/new-post.png" alt="phone"/>
                        <div className="contact_info_content">
                            <div className="contact_info_title">
                                Email

                            </div>
                            <div className="contact_info_text">
                                xxxxxxxxx@gmail.com

                            </div>

                        </div>

                    </div>
                    {/* address */}

                    <div className=" contact_info_item">
                        <img src="https://img.icons8.com/color/24/000000/address--v1.png" alt="phone"/>
                        <div className="contact_info_content">
                            <div className="contact_info_title">
                                Address

                            </div>
                            <div className="contact_info_text">
                                xxxxxxxxxxxxxxxxxxxx

                            </div>

                        </div>

                    </div>

                </div>
            </div>
        </div>


    </div>


    <div className="contact_form">
        <div className="container">
            <div className="row">
                <div className="col-lg-10 offset-lg-1">
                    <div className="contact_form_title">
                        <h3>Get in Touch</h3></div>
                    <form id="contact_form">
                        {/* <div className="contacr_form_name d-flex justify-content-between align-items-between"> */}
                        <div className="contact_form_top_bar">
                            <input type="text" class="form-control" id="#" placeholder="name@example.com"></input>
                            <input type="text" class="form-control" id="#" placeholder="name@example.com"></input>
                            <input type="text" class="form-control" id="#" placeholder="name@example.com"></input>
                        </div>

                        <div className="contact_form_text mt-4">
                            <textarea className="text_field" placeholder='Message'  cols="30"  rows="10">

                            </textarea>


                        </div>

                        <div className='contact_form_button'>
                            <button type="submit" className="btn btn-warning">Send Message</button>

                        </div>

                    </form>


                </div>

            </div>

        </div>

    </div>

    </div>


  )
}

export default Contact