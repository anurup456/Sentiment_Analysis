import React from 'react'
import './Aboutus.css'

 const Aboutus =() =>{
  return (
    <>
       
       <section>
            <div className = "image">
               <img src="" alt=''/>
            </div>

            <div className = "cnt">
                <h2>About Us</h2>
                {/* <span><!-- line here --></span> */}
                <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Nobis aspernatur voluptas inventore ab voluptates nostrum minus illo laborum harum laudantium earum ut, temporibus fugiat sequi explicabo facilis unde quos corporis!</p>
               
            </div>
        </section>
    
    </>
  )
}

export default Aboutus